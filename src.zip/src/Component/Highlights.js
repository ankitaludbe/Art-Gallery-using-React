import axios from "axios";
import React from "react";

const baseURL = "https://api.harvardartmuseums.org/Image?apikey=88f9eea6-60a7-4239-aa27-6f709b4e7484";

export default function App() {
  const [post, setPost] = React.useState(null);

  React.useEffect(() => {
    axios.get(baseURL).then((response) => {
      setPost(response.data);
    });
  }, []);
console.log(post)
  if (!post) return null;

  return (
    <div>
      {/* <h1>{post['records'][0]['baseimageurl']}</h1> */}
      
    </div>
  );
}